﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlinghallBengan.Bowling
{
    public class ChampionOfTheYearCalculator
    {
        public Member GetChampionOfTheYear(List<Cup> allCups, int year)
        {
            Member highest = null;
            float highestPercent = 0;
            
            foreach(var member in BowlingAlley.Instance.AllMembers)
            {
                float antalMatcher = 0;
                float vinster = 0;
                float percent = 0;
                foreach(var cup in allCups)
                {
                    foreach(var game in cup.PlayedGames.Where(r=>r.TimeStamp.Year == year))
                    {
                        if(game.Player1 == member || game.Player2 == member)
                        {
                            antalMatcher++;
                            if (game.GetWinnerOfGame() == member)
                                vinster++;
                        }
                    }
                }
                percent = vinster / antalMatcher;
                if(percent > highestPercent)
                {
                    highest = member;
                    highestPercent = percent;
                }
            }
            return highest;
        }
    }
}
