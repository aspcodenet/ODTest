﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlinghallBengan.Bowling
{
    public enum FeeType
    {
        //Lägger bara in alla olika typer av feeTypes det finns
        StartFee,
        MemberFee,
        CupFee,
        GameFee
    }
}
